function diamond_watch()
	local diamondNumber = globals.options.p1.diamondNumber
	diamondNumber = memory.readword(0xFF84F8)

globals.options.p1.diamondNumber = diamondNumber		
 end


diamondModule = {
	["free_diamond"] = free_diamond,
	["diamond_watch"] = diamond_watch,
}
return diamondModule